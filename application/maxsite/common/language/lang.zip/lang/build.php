<?php
/**
 * (c) MaxSite CMS
 *
 * Обработка входящих файлов
 *
 * http://localhost/cms/lang/build.php
 */

// DO NOT EDIT! ............................................................

if (!file_exists('mso/t.txt') or !file_exists('mso/t.txt'))
	die('File not found": <b>' . 'mso/</b><br> t.txt  <br>tf.txt');	

$t_array = fa('mso/t.txt');
file_put_contents('mso/mso-serialize.php', serialize($t_array));

$tf_array = fa('mso/tf.txt');
file_put_contents('mso/mso-f-serialize.php', serialize($tf_array));

$t_text = ft('mso/t.txt', $t_array);
$tf_text = ft('mso/tf.txt', $tf_array);

// общий словарь
file_put_contents('mso/mso-dictionary.php', "<"."?php return array(\n\n" . $tf_text . "\n" . $t_text . "\n\n);\n\n# end of file");

echo '<pre style="white-space: pre-wrap; line-height: 1.3;">' . htmlspecialchars($tf_text . "\n" . $t_text) . '</pre>';

function fa($fn)
{
	$t_array = file($fn);
	$t_array = array_unique($t_array);
	natcasesort($t_array);

	$out = array();
	
	foreach($t_array as $t)
	{
		$t = trim($t);
		if ($t)
		{
			if (is_numeric($t)) continue; // числа не переводим
			if (preg_match("#^[ -~—]+$#", $t)) continue; // английские слова пропускаем
			
			$out[] = trim($t);
		}
	}

	return $out;
}

function ft($fn, $t_array)
{
	file_put_contents($fn, implode("\n", $t_array)); // перезаписываем исходный файл

	$t_text = '';
	
	foreach($t_array as $t)
	{	
		$t = trim($t);
		$t = str_replace("'", "\'", $t);
		
		$t_text .= "'" . $t . "' => '',\n";
	}

	return $t_text;
}


# end of file