<?php
/**
 * (c) MaxSite CMS
 *
 * Сборка языковых фраз
 *
 * В application/maxsite/mso_config.php укажите
 *
 * define('MSO__PLEASE__ADD__FILE_LANG', $MSO->config['FCPATH'] . 'lang/lang.php');
 * 
 */

// DO NOT EDIT! ............................................................

if ($w and !is_numeric($w)) 
	file_put_contents('lang/mso/' . $label . '.txt', $w . NR, FILE_APPEND);


# end of file