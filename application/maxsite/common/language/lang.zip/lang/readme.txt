См. application/maxsite/common/language/readme.txt
