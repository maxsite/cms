<?php
/**
 * (c) MaxSite CMS
 *
 * Создание языковых файлов
 *
 * http://localhost/cms/lang/translation.php
 */

// нужно указать каталог языка. Каталог должен существовать
$lang = 'en'; 

// Дополнительные данные перевода
$lang_data = array(
	'version_maxsite' => '103',
	'date' => date('Y/m/d'),
	'author' => '',
	'author_url' => '',
);
 
// DO NOT EDIT! ............................................................

if (!file_exists('mso/mso-serialize.php')) die('Not found: mso/mso-serialize.php<br>');
if (!file_exists('mso/mso-f-serialize.php')) die('Not found: mso/mso-f-serialize.php<br>');
if (!file_exists($lang . '/dictionary.php')) die('Not found: dictionary.php<br>');

$t_text = file_get_contents('mso/mso-serialize.php');
if (!$t_text) die('Empty mso/mso-serialize.php<br>');

$tf_text = file_get_contents('mso/mso-f-serialize.php');
if (!$tf_text) die('Empty mso/mso-f-serialize.php<br>');

$t_array = unserialize($t_text);
$tf_array = unserialize($tf_text);

$dictionary = include $lang . '/dictionary.php';

$t_out_a = tra($t_array, $dictionary);
$tf_out_a = tra($tf_array, $dictionary);

$t_out_text = tro($t_out_a, strtoupper($lang) . ' backend', $lang_data);
$tf_out_text = tro($tf_out_a, strtoupper($lang) . ' frontend', $lang_data);

file_put_contents($lang . '/' . $lang . '.php', $t_out_text);
file_put_contents($lang . '/' . $lang . '-f.php', $tf_out_text);

echo '<pre style="white-space: pre-wrap; line-height: 1.3;">' . htmlspecialchars($tf_out_text . "\n\n" . $t_out_text) . '</pre>';


function tra($a, $d)
{
	$out = array();
	
	foreach($a as $t)
	{
		$t = trim($t);
		if (isset($d[$t]) and $d[$t]) 
			$out[$t] = $d[$t];
	}
	
	return $out;
}

function tro($a, $b, $lang_data)
{		
	$tt = '';
	
	foreach($a as $k => $v)
	{	
		$tt .= "'" . trim($k) . "' => '" . trim($v) . "',\n";
	}
	
	extract($lang_data);
	
	$t = 
"<"."?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Language for MaxSite CMS (c) http://max-3000.com/
 * 
 * Language: {$b}
 *
 * Version MaxSite CMS: {$version_maxsite}
 * Date: {$date}
 * Author: {$author_url}
 * Author URL: {$author_url}
 */
 
$"."lang = array(
 
{$tt}
);

# end of file";

	return $t;
}

# end of file